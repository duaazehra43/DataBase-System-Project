import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

class AddProduct implements ActionListener{

    JFrame f;
    JLabel id,id1,id2,id3,id4,id5,id8,id15,id6;
    JTextField t,t1,t2,t3,t4,t5,t6;
    JButton bb,b1,b2,b3;

    AddProduct(int i){}
    
    AddProduct(){
        f = new JFrame("Add Product");
        f.getContentPane().setBackground(new Color(200,228,186));
        f.setLayout(null);
        f.setResizable(false);



        id8 = new JLabel("New Product Details");
        id8.setBounds(120,30,500,50);
        id8.setFont(new Font("serif",Font.BOLD,25));
        id8.setForeground(Color.black);
        f.add(id8);
        
        
        id1 = new JLabel("Product Id");
        id1.setBounds(50,150,100,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        f.add(id1);

        t1=new JTextField();
        t1.setBounds(200,150,150,30);
        f.add(t1);

        id2 = new JLabel("Product Name");
        id2.setBounds(50,200,150,30);
        id2.setFont(new Font("serif",Font.BOLD,20));
        f.add(id2);

        t2=new JTextField();
        t2.setBounds(200,200,150,30);
        f.add(t2);

        id3= new JLabel("Color");
        id3.setBounds(50,250,100,30);
        id3.setFont(new Font("serif",Font.BOLD,20));
        f.add(id3);

        t3=new JTextField();
        t3.setBounds(200,250,150,30);
        f.add(t3);

        id4= new JLabel("Price");  
        id4.setBounds(50,300,200,30);
        id4.setFont(new Font("serif",Font.BOLD,20));
        f.add(id4);

        t4=new JTextField();
        t4.setBounds(200,300,150,30);
        f.add(t4);

        id5= new JLabel("Quantity");
        id5.setBounds(50,350,100,30);
        id5.setFont(new Font("serif",Font.BOLD,20));
        f.add(id5);

        t5=new JTextField();
        t5.setBounds(200,350,150,30);
        f.add(t5);
        
        id6= new JLabel("Quantity Can Buy");
        id6.setBounds(46,400,200,30);
        id6.setFont(new Font("serif",Font.BOLD,20));
        f.add(id6);

        t6=new JTextField();
        t6.setBounds(200,400,150,30);
        f.add(t6);


        bb = new JButton("Submit");
        bb.setBackground(Color.white);
   	    bb.setForeground(Color.black);
        bb.setBounds(50,500,150,40);
        bb.addActionListener(this);
        
        f.add(bb);

        b1=new JButton("Cancel");   
        b1.setBackground(Color.white);
   	    b1.setForeground(Color.BLACK);
        b1.setBounds(220,500,150,40);
        b1.addActionListener(this);
        
        f.add(b1);
        
        f.setVisible(true);
        f.setSize(440,650);
        f.setLocation(400,150);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
    }
 
    
    public void actionPerformed(ActionEvent ae){
         
    	String a = t1.getText();
        String b = t2.getText();
        String c = t3.getText();
        String d = t4.getText();
        String e = t5.getText();
        String f1= t6.getText();
        if(ae.getSource() == bb){
            try{
                DBConnection cc = new DBConnection();
                String q = "insert into product (pro_id, pro_name, pro_co, pro_pri, pro_qty, qty) values('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f1+"')";
                cc.s.executeUpdate(q);
                JOptionPane.showMessageDialog(null,"Details Successfully Inserted");
                f.setVisible(false);
                new Details();
            }catch(Exception ee){
                System.out.println("The error is:"+ee);
            }
        }else if(ae.getSource() == b1){
            f.setVisible(false);
            new Details();
        }
    }
    public static void main(String[ ] arg){
        new AddProduct();
    }
}