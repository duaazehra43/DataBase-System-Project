import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Application extends JFrame implements ActionListener{
     JFrame f = new JFrame("Online Shop");
     JLabel label1, img;
     JButton prod, cart, login, search, fdk, fdk1, quit;
     ImageIcon image;
     public Application() {
    	 f.setResizable(false);
    	 f.setSize(600,550);
    	 f.setLayout(null);
    	 f.getContentPane().setBackground(new Color(200,228,186));
    	 f.setLocationRelativeTo(null);
    	 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	 
    	 label1 = new JLabel("Welcome To Online Mart");
    	 label1.setBounds(155, 9, 500, 100);
    	 label1.setForeground(new Color(25,43,76));
    	 label1.setFont(new Font("Tahoma", Font.PLAIN, 30));
    	 f.add(label1);
    	 
         image = new ImageIcon("C:\\Users\\DUA\\Downloads\\icons8-shopping-cart-promotion-35.png");
    	 img = new JLabel(image);
    	 img.setBounds(70, 9, 100, 100);
    	 f.add(img);
    	 
    	 login = new JButton("Login");
    	 login.setBounds(75, 150, 450, 30);
    	 login.setBackground(Color.white);
    	 login.setForeground(Color.black);
    	 login.setFont(new Font("serif", Font.PLAIN, 24));
    	 login.addActionListener(this);
    	 f.add(login);
    	 
    	 prod = new JButton("All Products");
    	 prod.setBounds(75, 200, 450, 30);
    	 prod.setBackground(Color.white);
    	 prod.setForeground(Color.black);
    	 prod.setFont(new Font("serif", Font.PLAIN, 24));
    	 prod.addActionListener(this);
    	 f.add(prod);
    	 
    	 search = new JButton("Search Product");
    	 search.setBounds(75, 250, 450, 30);
    	 search.setBackground(Color.white);
    	 search.setForeground(Color.black);
    	 search.setFont(new Font("serif", Font.PLAIN, 24));
    	 search.addActionListener(this);
    	 f.add(search);
    	 
    	 fdk = new JButton("Give Feedback");
    	 fdk.setBounds(75, 300, 450, 30);
    	 fdk.setBackground(Color.white);
    	 fdk.setForeground(Color.black);
    	 fdk.setFont(new Font("serif", Font.PLAIN, 24));
    	 fdk.addActionListener(this);
    	 f.add(fdk);
    	 
    	 fdk1 = new JButton("Product Feedbacks");
    	 fdk1.setBounds(75, 350, 450, 30);
    	 fdk1.setBackground(Color.white);
    	 fdk1.setForeground(Color.black);
    	 fdk1.setFont(new Font("serif", Font.PLAIN, 24));
    	 fdk1.addActionListener(this);
    	 f.add(fdk1);
    	 
    	 quit = new JButton("Quit");
    	 quit.setBounds(75, 400, 450, 30);
    	 quit.setBackground(Color.white);
    	 quit.setForeground(Color.black);
    	 quit.setFont(new Font("serif", Font.PLAIN, 24));
    	 quit.addActionListener(this);
    	 f.add(quit);
    	 
    	 f.setVisible(true);
     }
     public static void main(String[] args) {
    	 new Application();
     }
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==login) {
			f.setVisible(false);
			new Login();
		}
		else if(e.getSource() == prod) {
			f.setVisible(false);
			new PrintProduct();
		}
		else if(e.getSource()==search) {
			f.setVisible(false);
			new SearchProduct();
		}
		else if(e.getSource() == fdk) {
			f.setVisible(false);
			new Reviews();
		}
		else if(e.getSource() == fdk1) {
			f.setVisible(false);
			new PrintFeedback();
		}
		else if(e.getSource()== quit) {
			System.exit(0);
		}
		
	}
}
