import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Bill implements ActionListener{
	JButton b,b1,b2;
	JFrame f;
	JLabel l3,l8,l9,l10,l11,l12,t3,t2,t,t1,t4;
	String price;
	public Bill(String pro_id ,String Name, String qty, String price, String s_add, String c_no, String bank, String pro_qty) {
		   f= new JFrame("Bill");
		   f.setResizable(false);
		   f.setSize(580,700);
		   f.setLayout(null);
		   f.getContentPane().setBackground(new Color(200,228,186));
		   f.setLocationRelativeTo(null);
		   f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		   
		   JLabel l1= new JLabel("Bill Recepit");
		   l1.setBounds(240,20,250,30);
	       l1.setFont(new Font("serif",Font.BOLD,28));
	       f.add(l1);
		   
	        JLabel l2 = new JLabel("Product Id: ");
	        l2.setBounds(50,100,150,30);
	        l2.setFont(new Font("serif",Font.BOLD,20));
	        f.add(l2);

	        l3=new JLabel(pro_id);
	        l3.setBounds(270,100,150,30);
	        f.add(l3);

	        JLabel l4 = new JLabel("Name: ");
	        l4.setBounds(50,150,150,30);
	        l4.setFont(new Font("serif",Font.BOLD,20));
	        f.add(l4);

	        t2=new JLabel(Name);
	        t2.setBounds(250,150,250,30);
	        f.add(t2);

	        JLabel l5= new JLabel("Price: ");
	        l5.setBounds(50,200,100,30);
	        l5.setFont(new Font("serif",Font.BOLD,20));
	        f.add(l5);

	        t3=new JLabel(price);
	        t3.setBounds(250,200,250,30);
	        f.add(t3);
	        
	        l8= new JLabel(qty);
	        l8.setBounds(50,350,100,30);
	        l8.setFont(new Font("serif",Font.BOLD,20));
	        l12= new JLabel(pro_qty);
	        l12.setBounds(50,350,100,30);
	        l12.setFont(new Font("serif",Font.BOLD,20));
	        //f.add(l8);

	        JLabel l6= new JLabel("Shipping Address: ");  
	        l6.setBounds(50,250,200,30);
	        l6.setFont(new Font("serif",Font.BOLD,20));
	        f.add(l6);

            t4=new JLabel(s_add);
	        t4.setBounds(250,250,250,100);
	        f.add(t4);
	        
	        l10 = new JLabel("Credit Card No: ");
			l10.setBounds(50,370,200,30);
		    l10.setFont(new Font("serif",Font.BOLD,20));
		    f.add(l10);
		       
		    t=new JLabel(c_no);
		    t.setBounds(250,370,250,30);
		    f.add(t);
		    
		    l11 = new JLabel("Bank Name: ");
			l11.setBounds(50,420,200,30);
		    l11.setFont(new Font("serif",Font.BOLD,20));
		    f.add(l11);
		       
		    t1=new JLabel(bank);
		    t1.setBounds(250,420,250,30);
		    f.add(t1);
	        
            
	        b = new JButton("Confirm Payment");
	        b.setBackground(Color.white);
	   	    b.setForeground(Color.black);
	        b.setBounds(50,540,235,40);
	        b.addActionListener(this);
	        f.add(b);
	        
	        b2=new JButton("Home");   
	        b2.setBackground(Color.white);
	   	    b2.setForeground(Color.black);
	        b2.setBounds(300,540,235,40);
	        b2.addActionListener(this);
	        f.add(b2);
		   
		   
		   f.setVisible(true);
	}
	public static void main(String[] args) {
		new Bill("", "","","","","","","");
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b2) {
		   f.setVisible(false);
		   new Application();
		}
		if(e.getSource()==b) {
			try{
                DBConnection cc = new DBConnection();
                String q = "insert into product (qty) values('"+l8.getText()+"') where pro_id="+ l3.getText() ;
                cc.s.executeUpdate(q);
            }catch(Exception ee){
                System.out.println("The error is:"+ee);
            }
			try{
                DBConnection cc = new DBConnection();
                String q = "update product set pro_qty='"+ (Integer.valueOf(l12.getText())-Integer.valueOf(l8.getText())) +"' where pro_id="+l3.getText();
                cc.s.executeUpdate(q);
            }catch(Exception ee){
                System.out.println("The error is:"+ee);
            }
			JOptionPane.showMessageDialog(null, "Ordered");
			
		}
		
		
	}
}
