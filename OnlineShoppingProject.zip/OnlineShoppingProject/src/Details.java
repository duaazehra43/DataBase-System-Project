import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class Details  implements ActionListener{

    JFrame f;
    JLabel l1,l2;
    JButton b1,b2,b3,b4,b5;

    Details(){
        f=new JFrame("Product Details");
        f.getContentPane().setBackground(new Color(200,228,186));
        f.setLayout(null);
        
        
        


        l2 = new JLabel("Product Details");
        l2.setBounds(190,20,500,100);
        l2.setFont(new Font("Tahoma", Font.PLAIN, 48));
        l2.setForeground(Color.BLACK);
        f.add(l2);

        b1=new JButton("Add");
        b1.setBounds(100,180,200,40);
        b1.setFont(new Font("serif",Font.BOLD,15));
        b1.addActionListener(this);
        b1.setBackground(Color.white);
        b1.setForeground(Color.black);
        f.add(b1);


        b2=new JButton("View");
        b2.setBounds(400,180,200,40);
        b2.setBackground(Color.white);
        b2.setForeground(Color.black);
        b2.setFont(new Font("serif",Font.BOLD,15));
        b2.addActionListener(this);
        f.add(b2);

        b3=new JButton("Remove");
        b3.setBounds(100,280,200,40);
        b3.setBackground(Color.white);
        b3.setForeground(Color.black);
        b3.setFont(new Font("serif",Font.BOLD,15));
        b3.addActionListener(this);
        f.add(b3);

        b4=new JButton("Update");
        b4.setBounds(400,280,200,40);
        b4.setBackground(Color.white);
        b4.setForeground(Color.black);
        b4.setFont(new Font("serif",Font.BOLD,15));
        b4.addActionListener(this);
        f.add(b4);
       
        b5=new JButton("Home");
        b5.setBounds(100,380,500,40);
        b5.setBackground(Color.white);
        b5.setForeground(Color.black);
        b5.setFont(new Font("serif",Font.BOLD,15));
        b5.addActionListener(this);
        f.add(b5);

        f.setVisible(true);
        f.setSize(700,500);
        f.setLocation(450,200);

    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b1){
            f.setVisible(false);
            new AddProduct();
            }
        
        if(ae.getSource()==b2){
            f.setVisible(false);
            new PrintProduct();
            }
        
        if(ae.getSource()==b3){
            f.setVisible(false);
            new RemoveProduct();
            }
        
        if(ae.getSource()==b4){
            f.setVisible(false);
            new SearchForAdmin();
            }
        
        if(ae.getSource()==b5) {
        	f.setVisible(false);
        	new Application();
        }
    }
    

    public static void main(String[ ] arg){
     new Details();
    }
}
