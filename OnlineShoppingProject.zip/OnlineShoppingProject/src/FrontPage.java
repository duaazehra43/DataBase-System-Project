import java.awt.*;
import javax.swing.*;
import java.lang.Thread;
import java.awt.event.*;
public class FrontPage implements ActionListener {

	JFrame f;
    JButton b;

    FrontPage(){
 
        f=new JFrame("Samsung Mobile Mart");
        f.setLayout(null);
        
        ImageIcon i1= new ImageIcon("F:\\java\\OnlineShoppingProject\\src\\image.jpg");
        Image i2=i1.getImage().getScaledInstance(900, 390, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel l1=new JLabel(i3);
        
        l1.setBounds(80, 100, 600, 510);
        f.add(l1);

        b = new JButton("CLICK HERE TO CONTINUE");
        b.setBackground(Color.white);
   	    b.setForeground(Color.black);
        b.setBounds(50,580,650,60);
        
        b.addActionListener(this);
        
  
        JLabel lid=new JLabel("Online Shopping Mart");
        lid.setBounds(70,25,1500,100);
        lid.setFont(new Font("serif",Font.PLAIN,70));
        lid.setForeground(Color.black);
        
        f.add(lid);
        f.add(b);
        
        
        f.getContentPane().setBackground(new Color(200,228,186));

        f.setVisible(true);
        f.setSize(760,750);
        f.setLocation(200,100);
        f.setLocationRelativeTo(null);
        
        
        while(true){
            lid.setVisible(false); // lid =  j label
            try{
                Thread.sleep(500); //1000 = 1 second
            }
            catch(Exception e){} 
            
            lid.setVisible(true);
            try{
                Thread.sleep(1000);
            }
            catch(Exception e){}
        }

    }
    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==b){
            f.setVisible(false);
            new Application();    
        }
    }
        
    public static void main(String[] arg){
         new FrontPage();
    }

}
