import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

class PrintData implements ActionListener{
    JFrame f;
    JLabel id8,id,aid,id1,aid1,id2,aid2,id3,aid3,id4,aid4,id9;
    String pro_id, pro_name, pro_co, pro_pri, pro_qty;
    JButton b1,b2;
    ImageIcon icon;

    PrintData(String pro_id){
    	try{
        	DBConnection con = new DBConnection();
        	String str = "select pro_id, pro_name, pro_co, pro_pri, pro_qty from product where pro_id = '"+pro_id+"'";
        	ResultSet rs= con.s.executeQuery(str);
        	while(rs.next()) {
        	    pro_id = rs.getString("pro_id");
        		pro_name = rs.getString("pro_name");
        		pro_co = rs.getString("pro_co");
        		pro_pri = rs.getString("pro_pri");
        		pro_qty = rs.getString("pro_qty");
        		}}
        	catch(Exception e){
        	e.printStackTrace();
        }
       

    	
   
 
        f=new JFrame("Print Data");
        f.setResizable(false);
        f.setSize(460,580);
        f.setLocation(450,200);
        f.getContentPane().setBackground(new Color(200,228,186));
        f.setLayout(null);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
        

        id8 = new JLabel("Product Details");
        id8.setBounds(160,10,250,30);
        id8.setFont(new Font("serif",Font.BOLD,25));
        f.add(id8);

        id = new JLabel("Product Id:");
        id.setBounds(50,70,120,30);
        id.setFont(new Font("serif",Font.BOLD,20));
        f.add(id);

        aid = new JLabel(pro_id);
        aid.setBounds(200,70,200,30);
        aid.setFont(new Font("serif",Font.BOLD,20));
        f.add(aid);

        id1 = new JLabel("Product Name:");
        id1.setBounds(50,120,150,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        f.add(id1);

        aid1 = new JLabel(pro_name);
        aid1.setBounds(200,120,300,30);
        aid1.setFont(new Font("serif",Font.BOLD,20));
        f.add(aid1);

  
        id2 = new JLabel("Product Color:"); 
        id2.setBounds(50,170,200,30);
        id2.setFont(new Font("serif",Font.BOLD,20));
        f.add(id2);

        aid2 = new JLabel(pro_co);
        aid2.setBounds(200,170,300,30);
        aid2.setFont(new Font("serif",Font.BOLD,20));
        f.add(aid2);

        id3= new JLabel("Product Price:");
        id3.setBounds(50,220,190,30);
        id3.setFont(new Font("serif",Font.BOLD,20));
        f.add(id3);

        aid3= new JLabel(pro_pri);
        aid3.setBounds(200,220,300,30);
        aid3.setFont(new Font("serif",Font.BOLD,20));
        f.add(aid3);


        id4= new JLabel("Product Quantity:");  
        id4.setBounds(50,270,200,30);
        id4.setFont(new Font("serif",Font.BOLD,20));
        f.add(id4);

        aid4= new JLabel(pro_qty);
        aid4.setBounds(240,270,300,30); 
        aid4.setFont(new Font("serif",Font.BOLD,20));
        f.add(aid4);

        
        b1=new JButton("Print");
        b1.setBackground(Color.white);
   	    b1.setForeground(Color.black);
        b1.setBounds(20,400,200,30);
        b1.addActionListener(this);
        f.add(b1);

        b2=new JButton("Cancel");
        b2.setBackground(Color.white);
   	    b2.setForeground(Color.black);
        b2.setBounds(230,400,200,30);
        b2.addActionListener(this);
        f.add(b2);
       f.setVisible(true);    
    }

        
    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==b1){
            JOptionPane.showMessageDialog(null,"Printed successfully");
            f.setVisible(false);
            new SearchProduct();
        }
        if(ae.getSource()==b2){
            f.setVisible(false);
            new Application();
        }
    }
    public static void main(String[] args){
        new PrintData("Print Data");
    }
}