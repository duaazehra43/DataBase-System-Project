import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.sql.ResultSetMetaData;

public class PrintFeedback implements ActionListener {
      JButton display, cancel;
      JTable table;
      JFrame f;
      PrintFeedback(){
    	 f= new JFrame("Product Reviews");
     	 f.setResizable(false);
     	 f.setSize(600,600);
     	 f.setLayout(null);
     	 f.getContentPane().setBackground(new Color(200,228,186));
     	 f.setLocationRelativeTo(null);
     	 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     	 
     	 table = new JTable();
     	 table.setVisible(true);
     	 table.setBackground(Color.white);
     	 table.setBounds(40,30,500,400);
     	 f.add(table);
     	 
     	JLabel l= new JLabel("Product ID");
      	 l.setBounds(45,5,100,30);
      	 f.add(l);
      	JLabel l1= new JLabel("Picture");
     	 l1.setBounds(175,5,100,30);
     	 f.add(l1);
     	JLabel l2= new JLabel("Feedback");
     	 l2.setBounds(300,5,100,30);
     	 f.add(l2);
     	JLabel l3= new JLabel("Rating");
     	 l3.setBounds(435,5,100,30);
     	 f.add(l3);
     	 display = new JButton("Display Data");
     	 display.setBounds(40,450,250,40);
     	 display.setBackground(Color.white);
   	     display.setForeground(Color.black);
     	 f.add(display);
     	 display.addActionListener(this);
     	 
     	 cancel = new JButton("Cancel");
    	 cancel.setBounds(295,450,250,40);
    	 cancel.setBackground(Color.white);
    	 cancel.setForeground(Color.black);
    	 f.add(cancel);
    	 cancel.addActionListener(this);
    	 f.setVisible(true);
     	 
      }
	@Override
	public void actionPerformed(ActionEvent e) {
	      if(e.getSource()==cancel) {
	    	  f.setVisible(false);
	    	  new Application();
	      }
	      else if(e.getSource()==display) {
	    	  try {
	    		  DBConnection con = new DBConnection();
	    		  String q= "select * from feedback";
	    		  ResultSet rs = con.s.executeQuery(q);
	    		  ResultSetMetaData rsmd = rs.getMetaData();
	    		  DefaultTableModel model = (DefaultTableModel) table.getModel();
	    		  int col = rsmd.getColumnCount();
	    		  String[] coln = new String[col];
	    		  for(int i=0; i<col; i++) {
	    			  coln[i] = rsmd.getColumnName(i+1);
	    		  }
	    		  model.setColumnIdentifiers(coln);
	    		  String pro_id, picture, feedback, rating;
	    		  while(rs.next()) {
	    			  pro_id = rs.getString(1);
	    			  picture = rs.getString(2);
	    			  feedback = rs.getString(3);
	    			  rating = rs.getString(4);
	    			  String[] row = {pro_id, picture, feedback, rating};
	    			  model.addRow(row);
	    		  }
	    	  }
	    	  catch(Exception e1) {
	    		  e1.printStackTrace();
	    	  }
	      }
		
	}
	public static void main(String[] args) {
		new PrintFeedback();
	}
}
