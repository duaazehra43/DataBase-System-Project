import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Reviews implements ActionListener {
	JFrame f;
    JLabel id,id1,id2,id3,id4,id5,id8,id15;
    JTextField t,t1,t4,t5;
    JTextArea t3;
    JButton bb, b1,br;
    
        Reviews(){
        f = new JFrame("Reviews Form");
        f.getContentPane().setBackground(new Color(200,228,186));
        f.setLayout(null);
        


        id8 = new JLabel("Please Provide Feedback");
        id8.setBounds(150,30,500,50);
        id8.setFont(new Font("serif",Font.BOLD,25));
        id8.setForeground(Color.black);
        f.add(id8);

 
        id1 = new JLabel("Product Id");
        id1.setBounds(50,150,100,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        f.add(id1);

        t1=new JTextField();
        t1.setBounds(200,150,300,30);
        f.add(t1);

        id2 = new JLabel("Picture");
        id2.setBounds(50,219,200,30);
        id2.setFont(new Font("serif",Font.BOLD,20));
        f.add(id2);

        br = new JButton("Upload Picture");
        br.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	JFileChooser file = new JFileChooser();
                file.setCurrentDirectory(new File(System.getProperty("user.home")));
                FileNameExtensionFilter filter = new FileNameExtensionFilter("*.Images","jpg","png");
                file.addChoosableFileFilter(filter);
                int res = file.showSaveDialog(null);
                if(res == JFileChooser.APPROVE_OPTION){
                  File selFile = file.getSelectedFile();
                 br.setText("Image Selected");
                }
            }
        });
        br.setBounds(200,219,300,30);
        f.add(br);

        id3= new JLabel("Feedback");
        id3.setBounds(50,300,100,30);
        id3.setFont(new Font("serif",Font.BOLD,20));
        f.add(id3);

        t3=new JTextArea();
        t3.setBounds(200,300,300,100);
        f.add(t3);

        id4= new JLabel("Rating (1-5)");  
        id4.setBounds(50,450,200,30);
        id4.setFont(new Font("serif",Font.BOLD,20));
        f.add(id4);

        t4=new JTextField();
        t4.setBounds(200,450,300,30);
        f.add(t4);


        bb = new JButton("Submit");
        bb.setBackground(Color.white);
   	    bb.setForeground(Color.black);
        bb.setBounds(50,550,230,40);
        bb.addActionListener(this);
        
        f.add(bb);

        b1=new JButton("Cancel");   
        b1.setBackground(Color.white);
   	    b1.setForeground(Color.black);
        b1.setBounds(300,550,230,40);
        b1.addActionListener(this);
        
        f.add(b1);
        
        f.setVisible(true);
        f.setSize(600,700);
        f.setLocation(400,150);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
    }

		@Override
		public void actionPerformed(ActionEvent e) {
				String a = t1.getText();
		        String b = br.getText();
		        String c = t3.getText();
		        String d = t4.getText();
		        
		        if(e.getSource() == bb){
		            try{
		                DBConnection cc = new DBConnection();
		                String q = "insert into feedback (pro_id, picture, feedback, rating) values('"+a+"','"+b+"','"+c+"','"+d+"')";
		                cc.s.executeUpdate(q);
		                JOptionPane.showMessageDialog(f,"Feedback Successfully Inserted");
		                f.setVisible(false);
		            }catch(Exception ee){
		                System.out.println("The error is:"+ee);
		            }
		            
		     
		        }
		        else if(e.getSource()==b1) {
		        	f.setVisible(false);
		        	new Application();
		        }
			
			
		}
		public static void main(String[] args) {
			new Reviews();
		}
}
