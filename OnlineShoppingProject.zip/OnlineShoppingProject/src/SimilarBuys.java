import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class SimilarBuys implements ActionListener{
	JButton home, cancel;
    JTable table;
    JFrame f;
    JScrollPane sp;
    JLabel l;
    ListSelectionModel model1;
    SimilarBuys(String pro_id){
  	 f= new JFrame("Similar Product Buyers");
   	 f.setResizable(false);
   	 f.setSize(600,600);
   	 f.setLayout(null);
   	 f.getContentPane().setBackground(new Color(200,228,186));
   	 f.setLocationRelativeTo(null);
   	 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   	 l= new JLabel(pro_id);
   	 
   	JLabel l= new JLabel("Customer Name");
 	 l.setBounds(45,5,100,30);
 	 f.add(l);
 	JLabel l1= new JLabel("Product");
	 l1.setBounds(175,5,100,30);
	 f.add(l1);
	JLabel l2= new JLabel("Quantity");
	 l2.setBounds(300,5,100,30);
	 f.add(l2);
	JLabel l3= new JLabel("Price");
	 l3.setBounds(435,5,100,30);
	 f.add(l3);
   	table = new JTable();
    DefaultTableModel model = new DefaultTableModel();
    String[] columns = {"Customer Name", "Product", "Quantity", "Price"};
    table.setBounds(40, 30, 500, 400);
    model.setColumnIdentifiers(columns);
    table.setModel(model);
    JTableHeader header = table.getTableHeader();
    header.setBackground(new Color(164, 46, 190));
    header.setForeground(Color.white);
    JScrollPane scroll = new JScrollPane(table);
    scroll.setBounds(50, 170, 800, 500);
    scroll.setHorizontalScrollBarPolicy(
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    scroll.setVerticalScrollBarPolicy(
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    final String[] cname = {""};
    final String[] prod = {""};
    final String[] proqty = {""};
    final String[] propri = {""};

    try {
     DBConnection con = new DBConnection();
     ResultSet rs = con.s.executeQuery("SELECT * FROM customer where prod='" + pro_id +"'");
     while (rs.next()) {
    	    cname[0] = rs.getString("c_name");
            prod[0] = rs.getString("prod");
            proqty[0] = rs.getString("qty");
            propri[0] = rs.getString("price");

            model.addRow(new Object[]{cname[0], prod[0], proqty[0], propri[0]});
        }
	  
  }
    catch(Exception e) {
   	 e.printStackTrace();
    }
		  
	f.add(table);  
	  
   	 
   	
   	 home = new JButton("Back");
   	 home.setBounds(50,450,490,40);
   	 home.setBackground(Color.white);
	 home.setForeground(Color.black);
   	 f.add(home);
   	 home.addActionListener(this);
   	 
   	 f.setVisible(true);
    }
	@Override
	public void actionPerformed(ActionEvent e) {
	      if(e.getSource()==home) {
	          f.setVisible(false);
	          new ProductView(l.getText());
	      }
		
	}
	public static void main(String[] args) {
		new SimilarBuys("");
	}
}
