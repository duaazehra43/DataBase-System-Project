import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;

class UpdateProduct extends AddProduct implements ActionListener{

    JFrame f;
    JLabel id,id1,id2,id3,id4,id5,id8,id15;
    JTextField t,t1,t2,t3,t4,t5;
    JButton b,b1,b2,b3; 

    UpdateProduct(String idaa){
        super(0);
        f=new JFrame("Update Product details");
        f.setSize(900,500);
        f.setLocation(450,250);
        f.getContentPane().setBackground(new Color(200,228,186));
        f.setLayout(null);   

        id8 = new JLabel("Update Product Detail:");
        id8.setBounds(50,10,500,50);
        id8.setFont(new Font("serif",Font.ITALIC,40));
        id8.setForeground(Color.black);
        f.add(id8);


        id1 = new JLabel("ID:");  
        id1.setBounds(50,100,100,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        f.add(id1);

        t1=new JTextField();
        t1.setBounds(200,100,150,30);
        f.add(t1);

        id2 = new JLabel("Name:");
        id2.setBounds(400,100,200,30);
        id2.setFont(new Font("serif",Font.BOLD,20));
        f.add(id2);

        t2=new JTextField();
        t2.setBounds(600,100,150,30);
        f.add(t2);

        id3= new JLabel("Color:");
        id3.setBounds(50,150,100,30);
        id3.setFont(new Font("serif",Font.BOLD,20));
        f.add(id3);

        t3=new JTextField();
        t3.setBounds(200,150,150,30);
        f.add(t3);

        id4= new JLabel("Price:");
        id4.setBounds(400,150,100,30);
        id4.setFont(new Font("serif",Font.BOLD,20));
        f.add(id4);

        t4=new JTextField();
        t4.setBounds(600,150,150,30);   
        f.add(t4);

        id5= new JLabel("Quantity:");
        id5.setBounds(50,200,100,30);
        id5.setFont(new Font("serif",Font.BOLD,20));
        f.add(id5);

        t5=new JTextField();
        t5.setBounds(200,200,150,30);
        f.add(t5);
        
        b=new JButton("Update");
        b.setBounds(250,400,100,30);
        b.setBackground(new Color(25,43,76));
   	    b.setForeground(Color.white);
        b.addActionListener(this);
        f.add(b);

        b1=new JButton("Cancel");
        b1.setBounds(450,400,100,30);
        b1.setBackground(new Color(25,43,76));
   	    b1.setForeground(Color.white);
        b1.addActionListener(this);
        f.add(b1);

        showData(idaa);
        f.setVisible(true);
    }

    int i=0;

    void showData(String s){
        try{
            DBConnection con = new DBConnection();
            String str = "select * from product where pro_id = '"+s+"'";
            ResultSet rs = con.s.executeQuery(str);

            if(rs.next()){
                f.setVisible(true);
                i=1;

                t1.setText(rs.getString("pro_id"));
                t2.setText(rs.getString("pro_name"));
                t3.setText(rs.getString("pro_co"));
                t4.setText(rs.getString("pro_pri"));
                t5.setText(rs.getString("pro_qty"));
            }
            if(i==0)
                JOptionPane.showMessageDialog(null,"Id not found");
            new SearchForAdmin();
        }catch(Exception ex){}
    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==b && i==1){
            try{
                DBConnection con = new DBConnection();
                String str = "update product set pro_name='"+t2.getText()+ "',pro_co='"+t3.getText()+"',pro_pri='"+t4.getText()+"',pro_qty='"+t5.getText()+"'where pro_id='"+t1.getText() + "'";
                con.s.executeUpdate(str);
                JOptionPane.showMessageDialog(null,"Successfully updated");
                f.setVisible(false);
                new SearchProduct();
            }catch(Exception e){
            	e.printStackTrace();
                //System.out.println("The error is:"+e);
            }
        }
        if(ae.getSource()==b1){
            f.setVisible(false);
            new Details();
        }
    }

    public static void main(String[] arg){
        new UpdateProduct("Update Product");
    }
}