import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputMethodEvent;
import java.awt.event.InputMethodListener;
import java.sql.ResultSet;

import javax.swing.*;
public class addToCart implements ActionListener{
	String pro_id, pro_name, pro_co, pro_pri, pro_qty;
	JButton b;
	JFrame f;
	JLabel l2,l11, l10,l8;
	String price;
   public addToCart(String prod, String qty) {
	   f= new JFrame("Cart");
	   f.setResizable(false);
	   f.setSize(400,550);
	   f.setLayout(null);
	   f.getContentPane().setBackground(new Color(200,228,186));
	   f.setLocationRelativeTo(null);
	   f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   
	   try {
		   DBConnection c= new DBConnection();
		   String str = "select pro_id, pro_name, pro_co, pro_pri, pro_qty from product where pro_id = '"+prod+"'";
       	ResultSet rs= c.s.executeQuery(str);
       	while(rs.next()) {
       	    pro_id = rs.getString("pro_id");
       		pro_name = rs.getString("pro_name");
       		pro_co = rs.getString("pro_co");
       		pro_pri = rs.getString("pro_pri");
       		pro_qty = rs.getString("pro_qty");
       		}}
       	catch(Exception e){
       	e.printStackTrace();
       }
	   
	   JLabel l = new JLabel("Cart");
       l.setBounds(170,20,120,30);
       l.setFont(new Font("serif",Font.BOLD,24));
       f.add(l);
	   
	   JLabel l1 = new JLabel("Product Id:");
       l1.setBounds(50,90,120,30);
       l1.setFont(new Font("serif",Font.BOLD,20));
       f.add(l1);

       l2 = new JLabel(pro_id);
       l2.setBounds(200,90,200,30);
       l2.setFont(new Font("serif",Font.BOLD,20));
       f.add(l2);

       JLabel l3 = new JLabel("Product Name:");
       l3.setBounds(50,150,150,30);
       l3.setFont(new Font("serif",Font.BOLD,20));
       f.add(l3);

       JLabel l4 = new JLabel(pro_name);
       l4.setBounds(200,150,300,30);
       l4.setFont(new Font("serif",Font.BOLD,20));
       f.add(l4);

 
       JLabel l5 = new JLabel("Product Color:"); 
       l5.setBounds(50,210,200,30);
       l5.setFont(new Font("serif",Font.BOLD,20));
       f.add(l5);

       JLabel l6 = new JLabel(pro_co);
       l6.setBounds(200,210,300,30);
       l6.setFont(new Font("serif",Font.BOLD,20));
       f.add(l6);

       JLabel l7= new JLabel("Product Price:");
       l7.setBounds(50,270,190,30);
       l7.setFont(new Font("serif",Font.BOLD,20));
       f.add(l7);

       l8= new JLabel(pro_pri);
       l8.setBounds(200,270,300,30);
       l8.setFont(new Font("serif",Font.BOLD,20));
       f.add(l8);
       
       JLabel l9= new JLabel("Quantity:");
       l9.setBounds(50,330,200,30);
       l9.setFont(new Font("serif",Font.BOLD,20));
       f.add(l9);
       
       l10= new JLabel(qty);
       l10.setBounds(200,330,300,30); 
       l10.setFont(new Font("serif",Font.BOLD,20));
       f.add(l10);
       
       
       l11= new JLabel(pro_qty);
       l11.setBounds(200,300,300,30); 
       l11.setFont(new Font("serif",Font.BOLD,20));                                                                                                                               //f.add(l11);
      

       b=new JButton("Proceed For Payment");
       b.setBackground(Color.white);
  	   b.setForeground(Color.black);
  	   b.setLayout(null);
       b.setBounds(20,450,350,30);
       b.addActionListener(this);
       f.add(b);
  
       f.setVisible(true);
	   
   }
   public static void main(String[] args) {
	   new addToCart("", "");
   }
@Override
public void actionPerformed(ActionEvent e) {
	if(e.getSource()==b) {
		f.setVisible(false);
		
		new payment(l2.getText(), l8.getText() , l10.getText(), l11.getText());
	}
	
}
}
