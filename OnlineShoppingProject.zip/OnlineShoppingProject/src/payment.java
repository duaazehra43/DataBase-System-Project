import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class payment implements ActionListener{
	JButton b,b1,b2;
	JFrame f;
	JTextField t,t1,t2;
	JTextArea t4;
	JLabel l3,l8,l9,l10,l11,l12,t3;
	String price;
	public payment(String pro_id , String pro_pri, String qty , String pro_qty) {
		   f= new JFrame("Payment Procedure");
		   f.setResizable(false);
		   f.setSize(590,700);
		   f.setLayout(null);
		   f.getContentPane().setBackground(new Color(200,228,186));
		   f.setLocationRelativeTo(null);
		   f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		   
		   JLabel l1= new JLabel("Payment");
		   l1.setBounds(240,20,250,30);
	       l1.setFont(new Font("serif",Font.BOLD,28));
	       f.add(l1);
		   
	        JLabel l2 = new JLabel("Product Id: ");
	        l2.setBounds(50,100,150,30);
	        l2.setFont(new Font("serif",Font.BOLD,20));
	        f.add(l2);

	        l3=new JLabel(pro_id);
	        l3.setBounds(270,100,150,30);
	        f.add(l3);

	        JLabel l4 = new JLabel("Name: ");
	        l4.setBounds(50,150,150,30);
	        l4.setFont(new Font("serif",Font.BOLD,20));
	        f.add(l4);

	        t2=new JTextField();
	        t2.setBounds(250,150,250,30);
	        f.add(t2);
	        
	        l8= new JLabel(qty);
	        l8.setBounds(50,350,100,30);
	        l8.setFont(new Font("serif",Font.BOLD,20));
	        l12= new JLabel(pro_qty);
	        l12.setBounds(50,350,100,30);
	        l12.setFont(new Font("serif",Font.BOLD,20));
	        l9= new JLabel(pro_pri);
	        l9.setBounds(50,350,100,30);
	        l9.setFont(new Font("serif",Font.BOLD,20));
	        //f.add(l8);

	        JLabel l6= new JLabel("Shipping Address: ");  
	        l6.setBounds(50,250,200,30);
	        l6.setFont(new Font("serif",Font.BOLD,20));
	        f.add(l6);

            t4=new JTextArea();
	        t4.setBounds(250,250,250,100);
	        f.add(t4);
	        
	        l10 = new JLabel("Credit Card No: ");
			l10.setBounds(50,370,200,30);
		    l10.setFont(new Font("serif",Font.BOLD,20));
		    f.add(l10);
		       
		    t=new JTextField();
		    t.setBounds(250,370,250,30);
		    f.add(t);
		    
		    l11 = new JLabel("Bank Name: ");
			l11.setBounds(50,420,200,30);
		    l11.setFont(new Font("serif",Font.BOLD,20));
		    f.add(l11);
		       
		    t1=new JTextField();
		    t1.setBounds(250,420,250,30);
		    f.add(t1);
	        
            
	        b = new JButton("See Bill");
	        b.setBackground(Color.white);
	   	    b.setForeground(Color.black);
	        b.setBounds(50,540,235,40);
	        b.addActionListener(this);
	        f.add(b);
	        
	        b2=new JButton("Home");   
	        b2.setBackground(Color.white);
	   	    b2.setForeground(Color.black);
	        b2.setBounds(300,540,235,40);
	        b2.addActionListener(this);
	        f.add(b2);
		   
		   
		   f.setVisible(true);
	}
	public static void main(String[] args) {
		new payment("", "","","");
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b2) {
		   f.setVisible(false);
		   new Application();
		}
		if(e.getSource()==b) {
			try{
                DBConnection cc = new DBConnection();
                String q = "insert into customer (c_name, prod, s_add,c_no, b_name, qty, pro_pri) values('"+t2.getText()+"','"+l3.getText()+"','"+t4.getText()+"','"+t.getText()+"','"+t1.getText()+"','"+l8.getText()+"','"+l9.getText()+"')";
                cc.s.executeUpdate(q);
            }catch(Exception ee){
                System.out.println("The error is:"+ee);
            }
			try {
	        	DBConnection con = new DBConnection();
	        	String sql = "select price from customer";
	        	ResultSet rs = con.s.executeQuery(sql);
	        	
	        	while(rs.next()) {
	        		price= rs.getString("price");
	        	}
	        	System.out.print("/n" + price);
	        }catch(Exception ee) {
	        	ee.printStackTrace();
	        }
			new Bill(l3.getText(), t2.getText(), l8.getText(), price, t4.getText(), t.getText(), t1.getText(), l12.getText());
			
		}
		
		
	}
}